package com.hmp.hotelmaintenance;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private String pendingText = "";
    private final int PICK_FILE = 701;
    private final int SAVE_FILE = 702;
    private final ExecutorService networkExecutor = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        webView.setBackgroundColor(0xFFF3F7F5);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.getSettings().setSupportZoom(false);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AppBridge(), "Android");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                startActivityForResult(intent, PICK_FILE);
                return true;
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class AppBridge {
        @JavascriptInterface public boolean isOnline() {
            try {
                ConnectivityManager cm = (ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
                if (cm == null) return false;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    Network n = cm.getActiveNetwork();
                    NetworkCapabilities c = n == null ? null : cm.getNetworkCapabilities(n);
                    return c != null && (c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) || c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));
                }
                return cm.getActiveNetworkInfo() != null && cm.getActiveNetworkInfo().isConnected();
            } catch (Exception e) { return false; }
        }
        @JavascriptInterface public void cloudRequest(String endpoint, String method, String payload) {
            networkExecutor.execute(() -> {
                HttpURLConnection conn = null;
                String result = "";
                String status = "error";
                String message = "Échec de connexion au serveur";
                try {
                    URL url = new URL(endpoint);
                    if (!"https".equalsIgnoreCase(url.getProtocol())) throw new Exception("HTTPS obligatoire");
                    conn = (HttpURLConnection)url.openConnection();
                    conn.setRequestMethod("POST".equalsIgnoreCase(method) ? "POST" : "GET");
                    conn.setConnectTimeout(15000);
                    conn.setReadTimeout(20000);
                    conn.setRequestProperty("Accept", "application/json");
                    if ("POST".equalsIgnoreCase(method)) {
                        conn.setDoOutput(true);
                        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                        try (OutputStream out = conn.getOutputStream()) { out.write(payload.getBytes(StandardCharsets.UTF_8)); }
                    }
                    int code = conn.getResponseCode();
                    InputStream in = code >= 200 && code < 400 ? conn.getInputStream() : conn.getErrorStream();
                    if (in != null) {
                        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                        byte[] data = new byte[4096]; int count;
                        while ((count = in.read(data)) != -1) buffer.write(data, 0, count);
                        result = buffer.toString("UTF-8"); in.close();
                    }
                    if (code >= 200 && code < 300) { status = "ok"; message = "Connexion serveur réussie"; }
                    else message = "Erreur serveur HTTP " + code;
                } catch (Exception e) { message = e.getMessage() == null ? message : e.getMessage(); }
                finally { if (conn != null) conn.disconnect(); }
                final String st = status, msg = message, body = result;
                runOnUiThread(() -> {
                    if (webView != null) webView.evaluateJavascript("window.onCloudSyncResult && window.onCloudSyncResult(" + JSONObject.quote(st) + "," + JSONObject.quote(msg) + "," + JSONObject.quote(body) + ")", null);
                });
            });
        }
        @JavascriptInterface public void saveText(String filename, String content) {
            runOnUiThread(() -> {
                pendingText = content;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(filename.endsWith(".json") ? "application/json" : "text/csv");
                intent.putExtra(Intent.EXTRA_TITLE, filename);
                startActivityForResult(intent, SAVE_FILE);
            });
        }
        @JavascriptInterface public void message(String text) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, text, Toast.LENGTH_SHORT).show());
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE) {
            if (fileCallback != null) {
                Uri[] result = resultCode == Activity.RESULT_OK && data != null ? new Uri[]{data.getData()} : null;
                fileCallback.onReceiveValue(result); fileCallback = null;
            }
        } else if (requestCode == SAVE_FILE && resultCode == Activity.RESULT_OK && data != null) {
            try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                out.write(pendingText.getBytes(StandardCharsets.UTF_8));
                Toast.makeText(this, "Fichier enregistré", Toast.LENGTH_LONG).show();
            } catch (Exception e) { Toast.makeText(this, "Erreur d'enregistrement", Toast.LENGTH_LONG).show(); }
        }
    }
    @Override public void onBackPressed() {
        if (webView != null) webView.evaluateJavascript("if(window.page!=='home'){go('home')}else{Android.message('Vous êtes à l’accueil')}", null);
        else super.onBackPressed();
    }
    @Override protected void onDestroy() { networkExecutor.shutdown(); super.onDestroy(); }
}
